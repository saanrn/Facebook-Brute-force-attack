# SarifBachha Commands
apt update && upgrade
apt install git
apt install python
apt install python2
Pip2 install requests
Pip2 install mechanize
git clone https:// github.com/SarifBachha/Rn
cd Rn
Ls
Python2 kamina.py



test Rn
